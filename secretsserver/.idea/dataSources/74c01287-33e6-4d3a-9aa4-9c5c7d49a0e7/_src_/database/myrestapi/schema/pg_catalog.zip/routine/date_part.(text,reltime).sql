create function pg_catalog.date_part(text, reltime) returns double precision
LANGUAGE SQL
AS $$
select pg_catalog.date_part($1, cast($2 as pg_catalog.interval))
$$;
